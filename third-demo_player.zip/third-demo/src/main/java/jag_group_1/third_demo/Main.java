package jag_group_1.third_demo;

import org.hibernate.Session;
import org.hibernate.Transaction;

import model.MyConnection;
import model.Player;

public class Main {

	public static void main(String[] args) {
		Session session1=MyConnection.getConnection();
		Player player1=(Player) session1.get(Player.class, 2680);
		System.out.println(player1);
		Session session2=MyConnection.getConnection();
		Player player2=(Player) session2.get(Player.class, 2680);
		System.out.println(player2);
		session1.close();
		session2.close();
		System.out.println("Done");
	}

}
