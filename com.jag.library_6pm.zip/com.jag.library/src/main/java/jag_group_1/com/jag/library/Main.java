package jag_group_1.com.jag.library;

import org.hibernate.Session;

import jag_group_1.com.jag.library.model.MyConnection;
import jag_group_1.com.jag.library.model.Patient;

public class Main {
	public static void main(String[] args) {
		Session session = MyConnection.getConnection();
		Patient patient=(Patient) session.get(Patient.class, 2630);
		System.out.println(patient);
	}
}
