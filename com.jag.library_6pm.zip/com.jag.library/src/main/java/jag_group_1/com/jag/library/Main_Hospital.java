package jag_group_1.com.jag.library;

import javax.print.Doc;

import org.hibernate.Session;
import org.hibernate.Transaction;

import jag_group_1.com.jag.library.model.Doctor;
import jag_group_1.com.jag.library.model.MyConnection;
import jag_group_1.com.jag.library.model.Patient;

public class Main_Hospital {
	public static void main(String[] args) {
		Session session = MyConnection.getConnection();
//		Doctor doctor=new Doctor("Suresh");
		Transaction tran = session.beginTransaction();
//		session.persist(doctor);
//		Doctor doctor=(Doctor) session.get(Doctor.class, 2480);
		Patient patient = (Patient) session.get(Patient.class, 2630);
		Doctor doctor=new Doctor("Yousuf");
		session.persist(doctor);
		patient.getDoctors().add(doctor);
		session.persist(doctor);
		doctor.getPatients().add(patient);		//is done
//		System.out.println(doctor);
//		for(Patient p:doctor.getPatients())
//			System.out.println(p);
//		Patient patient=new Patient("Dinesh");
//		patient.getDoctors().add(doctor);
//		doctor.getPatients().add(patient);
//		session.persist(patient);
		tran.commit();
		System.out.println("Done");
	}
}
