package jag_group_1.com.jag.library.model;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Main {

	public static void main(String[] args) {
		//		1610		shiv khera
		Session session = MyConnection.getConnection();
		Transaction tran = session.beginTransaction();
//		Author author=new Author("Shiv", "Khera");
//		session.persist(author);
		//find existing author. get managed entity of author
		
		  Author author=(Author) session.get(Author.class, 2280);
		  System.out.println(author);
		  System.out.println("Books by "+author.getFirstName()); 
		  for(Book book:author.getBooks()) 
			  System.out.println(book);
		 
		
		
//		  Book book=new Book(); 
//		  book.setTitle("I can win"); 
//		  book.setPrice(205.50f); //
//		  // book.setAuthor(author); 
//		  book.getAuthors().add(author);
//		  session.persist(book);
//		 
		 
		tran.commit();
		System.out.println("Done");
	}

}
