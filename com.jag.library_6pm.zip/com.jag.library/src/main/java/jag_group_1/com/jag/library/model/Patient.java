package jag_group_1.com.jag.library.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Patient {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	int id;
	String name;
	@ManyToMany(targetEntity=Doctor.class,mappedBy="patients")
	List<Doctor> doctors;
	public Patient()
	{
		doctors=new ArrayList<Doctor>();
	}
	public Patient(int id, String name, List<Doctor> doctors) {
		this();
		this.id = id;
		this.name = name;
		this.doctors = doctors;
	}
	public Patient(String name) {
		this();
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Doctor> getDoctors() {
		return doctors;
	}
	public void setDoctors(List<Doctor> doctors) {
		this.doctors = doctors;
	}
	@Override
	public String toString() {
		return "Patient [id=" + id + ", name=" + name + ", doctors=" + doctors.size() + "]";
	}
	
}
