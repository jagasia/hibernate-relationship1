package jag_group_1.com.jag.library.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	int id;
	String name;
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name="Treatment",joinColumns=@JoinColumn(name="doctor_id",referencedColumnName="id"),
	inverseJoinColumns=@JoinColumn(name="patient_id",referencedColumnName="id"))
	List<Patient> patients;
	public Doctor() {
		patients=new ArrayList<Patient>();
	}
	public Doctor(int id, String name) {
		this();
		this.id = id;
		this.name = name;
	}
	public Doctor(String name) {
		this();
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Patient> getPatients() {
		return patients;
	}
	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}
	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", patients=" + patients.size() + "]";
	}
	
}
