package jag_group_1.com.jag.library.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
public class Book {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;
	private String title;
	private float price;
	@ManyToMany(targetEntity = Author.class, cascade = CascadeType.ALL)
	@JoinTable(name="LIBRARY",joinColumns=@JoinColumn(name="book_id",referencedColumnName="id"),inverseJoinColumns=@JoinColumn(name="author_id",referencedColumnName="id"))
	List<Author> authors;
	public Book() 
	{
		authors=new ArrayList<Author>();
	}
	public Book(int id, String title, float price, List<Author> authors) {
		this();
		this.id = id;
		this.title = title;
		this.price = price;
		this.authors = authors;
	}
	public Book(String title, float price, List<Author> authors) {
		this();
		this.title = title;
		this.price = price;
		this.authors = authors;
	}	
	public Book(String title, float price) {
		this();
		this.title = title;
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
	public List<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(List<Author> authors) {
		this.authors = authors;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + ", price=" + price + ", authors=" + authors.size() + "]";
	}		
	
}
